using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Togglemethod : MonoBehaviour
{
   public GameObject jetComponent;
   private bool isVisble = true;

   public void Toogle()
   {
    if(isVisble)
    {
        jetComponent.SetActive(false);
        isVisble = false;
    }
    else
    {
         jetComponent.SetActive(true);
        isVisble = true;
    }
   }
}
